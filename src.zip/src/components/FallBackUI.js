import React from 'react'

function FallBackUI() {
    return (
        <div>
            <p>Please try again later</p>
        </div>
    )
}

export default FallBackUI
