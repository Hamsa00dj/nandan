import React from 'react'

function PersonDetail() {
    return (
        <div>
            Person Details component
        </div>
    )
}

export default PersonDetail



